function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6bD1rf6oG4y":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

