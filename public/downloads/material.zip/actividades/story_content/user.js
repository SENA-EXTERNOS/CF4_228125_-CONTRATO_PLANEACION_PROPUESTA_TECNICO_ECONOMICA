function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Y19KK380OI":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

